/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.codere.app;


import com.codere.controller.ControllerCliente_2;
import com.codere.model.Cliente;

/**
 *
 * @author heibe
 */
public class CrudJava {
    
    public static void main(String[] args) {
        
        ControllerCliente_2 objC = new ControllerCliente_2();
      
        objC.iniciar();
       // this.setLocationRelativeTo(null); 
		
	}
    
}
